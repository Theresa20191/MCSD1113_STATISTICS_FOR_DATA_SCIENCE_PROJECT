
# Load necessary libraries
library(scales)
library(dplyr)
library(ggplot2)
library(stats)
library(caret)
library(randomForest)
library(e1071)
library(ROSE)
library(doParallel)
library(data.table)
library(pROC)

#----------------------------------------#
#----   Part 1 : Exploratory Data   -----#
#----------------------------------------#


setwd("/Users/theresalee/Desktop/UTM/SEM1 /Statistics/Assignment/")

# Load CSV file
data<- read.csv("application_record.csv", sep = "\t", header = TRUE)

# Data exploration - Size of data before split the data into multiple column
cat("Size of the data before split the data into multiple column (rows, columns):", dim(data), "\n")

# Split the data into multiple columns
split_data <- strsplit(data$ID.CODE_GENDER.FLAG_OWN_CAR.FLAG_OWN_REALTY.CNT_CHILDREN.AMT_INCOME_TOTAL.NAME_INCOME_TYPE.NAME_EDUCATION_TYPE.NAME_FAMILY_STATUS.NAME_HOUSING_TYPE.DAYS_BIRTH.DAYS_EMPLOYED.FLAG_MOBIL.FLAG_WORK_PHONE.FLAG_PHONE.FLAG_EMAIL.OCCUPATION_TYPE.CNT_FAM_MEMBERS, ",")

# Create a new data frame
new_data <- as.data.frame(do.call(rbind, split_data))

# Rename the columns
colnames(new_data) <- c("ID", "CODE_GENDER", "FLAG_OWN_CAR", "FLAG_OWN_REALTY", "CNT_CHILDREN", "AMT_INCOME_TOTAL", "NAME_INCOME_TYPE", "NAME_EDUCATION_TYPE", "NAME_FAMILY_STATUS", "NAME_HOUSING_TYPE", "DAYS_BIRTH", "DAYS_EMPLOYED", "FLAG_MOBIL", "FLAG_WORK_PHONE", "FLAG_PHONE", "FLAG_EMAIL", "OCCUPATION_TYPE", "CNT_FAM_MEMBERS")

# Data exploration - Size of data after split the data into multiple column
cat("Size of the data after split the data into multiple column (rows, columns):", dim(new_data), "\n")

# Determine the type of each data variable
data_types <- sapply(data, class)
cat("Data types of each variable:\n", data_types, "\n")

data_types <- sapply(new_data, class)
cat("Data types of each variable:\n", data_types, "\n")

# Convert numeric columns to numeric
numeric_cols <- c("CNT_CHILDREN", "AMT_INCOME_TOTAL", "DAYS_BIRTH", "DAYS_EMPLOYED", "FLAG_MOBIL", "FLAG_WORK_PHONE", "FLAG_PHONE", "FLAG_EMAIL", "CNT_FAM_MEMBERS")
new_data[numeric_cols] <- lapply(new_data[numeric_cols], as.numeric)

# Summary statistics for numeric variables
str(new_data)
summary(new_data)

# Convert AMT_INCOME_TOTAL to numeric 
new_data$AMT_INCOME_TOTAL <- as.numeric(new_data$AMT_INCOME_TOTAL)

# Missing values handling
missing_values <- sapply(new_data, function(x) sum(is.na(x) | x == "" | x == ""))
missing_values_with_names <- data.frame(Column = names(missing_values), Missing_Blank_Count = missing_values)

# Exclude columns with zero missing or blank values
missing_values_with_names <- missing_values_with_names[missing_values_with_names$Missing_Blank_Count > 0, ]

cat("Missing or blank values per column:\n")
print(missing_values_with_names)

#Deletion: Remove rows or columns with missing values. 
#This is appropriate when the missing values are random, and removing them doesn't introduce bias.

# Remove rows with NA or blank values
rows_with_blanks <- apply(new_data, 1, function(row) any(row == ""))
new_data <- new_data[!rows_with_blanks, ]

# Summary statistics after remove rows with NA or blank values
cat("Size of the data after remove rows with NA or blank values(rows, columns):", dim(new_data), "\n")
str(new_data)
summary(new_data)



#----------------------------------------#
#----   Part 2 : Data Descriptive   -----#
#----------------------------------------#



# Descriptive analysis

mean_income <- mean(new_data$AMT_INCOME_TOTAL)
median_income <- median(new_data$AMT_INCOME_TOTAL)
mode_income <- as.numeric(names(table(new_data$AMT_INCOME_TOTAL))[which.max(table(new_data$AMT_INCOME_TOTAL))])

cat("Mean Income:", mean_income, "\n")
cat("Median Income:", median_income, "\n")
cat("Mode Income:", mode_income, "\n")


# Bar chart for Categorical Variables
new_data$FLAG_OWN_CAR <- factor(new_data$FLAG_OWN_CAR, levels = c('N', 'Y'), labels = c('No', 'Yes'))
barplot(table(new_data$FLAG_OWN_CAR), main="Owns a Car", xlab="Owns a Car", ylab="Count", col="skyblue")

new_data$CODE_GENDER <- factor(new_data$CODE_GENDER, levels = c('F', 'M'), labels = c('Female', 'Male'))
barplot(table(new_data$CODE_GENDER), main = "Gender Distribution", xlab = "Gender", col = "lightgreen")

new_data$FLAG_OWN_REALTY <- factor(new_data$FLAG_OWN_REALTY, levels = c('N', 'Y'), labels = c('No', 'Yes'))
barplot(table(new_data$FLAG_OWN_REALTY), main = "Owns Realty", xlab = "Owns Realty", col = "orange")


# Pie charts

# Function to create a pie chart with percentage labels and legend
create_pie_chart <- function(table_data, main_title) {
  pie_percent <- prop.table(table_data) * 100  # Calculate percentages
  
  # Create the pie chart with formatted percentage labels and matching legend colors
  pie(table_data, labels = sprintf("%.1f%%", pie_percent), main = main_title, col = rainbow(length(table_data)))
  
  # Add legend to the right of the chart
  legend("bottomright", legend = names(table_data), fill = rainbow(length(table_data)), cex = 0.8)
}

# Create pie charts with formatted percentage labels and matching legend colors
create_pie_chart(table(new_data$NAME_INCOME_TYPE), "Income Type Distribution")
create_pie_chart(table(new_data$NAME_EDUCATION_TYPE), "Education Level Distribution")
create_pie_chart(table(new_data$NAME_FAMILY_STATUS), "Family Status Distribution")

# Create a stem-and-leaf plot without title
stem(new_data$AMT_INCOME_TOTAL)

# Histograms
hist(new_data$AMT_INCOME_TOTAL, main = "Income Distribution", xlab = "Income", col = "purple")
hist(new_data$DAYS_BIRTH, main = "Age Distribution", xlab = "Days Birth", col = "cyan")
hist(new_data$CNT_FAM_MEMBERS, main = "Family Members Distribution", xlab = "Family Members", col = "pink")


# Boxplot for Numeric Variable
boxplot(new_data$AMT_INCOME_TOTAL, main="Boxplot", ylab="Income", col="orange")

# Calculate boxplot statistics
bp_stats <- boxplot.stats(new_data$AMT_INCOME_TOTAL)

# Print the boxplot details
cat("Median:", bp_stats$stats[3], "\n")
cat("Upper Hinge:", bp_stats$stats[4], "\n")
cat("Lower Hinge:", bp_stats$stats[2], "\n")
cat("Upper Whisker:", bp_stats$stats[5], "\n")
cat("Lower Whisker:", bp_stats$stats[1], "\n")
cat("Outliers:", bp_stats$out, "\n")

# Additional Descriptive Analysis
summary(new_data)

#----------------------------------------#
#---- Part 3 : Inferential Analysis -----#
#----------------------------------------#


# Perform the t-test
t.test(new_data$AMT_INCOME_TOTAL, mu = 50000)

# Result as below: 
# t-value: 683.25
# Degrees of freedom: 304353
# p-value: < 2.2e-16 (very close to zero)
# 95% confidence interval for the mean: $194,452.4 to $195,283.5
# Sample mean: $194,868
# This suggests that the mean income is significantly different from $50,000, with a 95% confidence interval providing a range for the true mean.

# 2-sample t-test for AMT_INCOME_TOTAL by gender
t.test(AMT_INCOME_TOTAL ~ CODE_GENDER, data = new_data)

# Result: 
# A p-value much smaller than the conventional significance level of 0.05.
# The estimated mean income for group F (female) is 180,953.1, while the estimated mean income for group M (male) is 218,121.5. The confidence interval for the difference in means suggests that the true difference falls between -38,085.48 and -36,251.40 with 95% confidence.

# Reload the data using the correct delimiter (comma)
data <- read.csv("application_record.csv", header = TRUE)

# Goodness of fit test (Chi-square)
# Chi-square test for the distribution of NAME_INCOME_TYPE
# Calculate the frequency of each unique value in the NAME_INCOME_TYPE column
income_type_table <- table(new_data$NAME_INCOME_TYPE)

# Perform a chi-squared test
chisq_test <- chisq.test(income_type_table)
chisq_test 
# Calculate expected probabilities
expected_prob <- chisq_test$expected / sum(chisq_test$expected)

# Convert the result to a data frame and add more indicators
income_type_results <- data.frame(
  "Income Type" = names(income_type_table),
  "Frequency" = as.vector(income_type_table),
  "Chi-squared statistic" = chisq_test$statistic,
  "Degrees of freedom" = chisq_test$parameter,
  "P-value" = chisq_test$p.value,
  "Expected Probabilities" = expected_prob
)

# Print the result
print(income_type_results)


# Result: 
# income_type_table, and the results indicate a statistically significant difference among the categories. 
# The p-value is very close to zero (p-value < 2.2e-16), suggesting that there is strong evidence to reject the null hypothesis that the observed frequencies are equal to the expected frequencies.

# Chi-square test for independence between CODE_GENDER and NAME_EDUCATION_TYPE
# Define the significance level (alpha)
alpha <- 0.05

# Create a cross table of CODE_GENDER and NAME_EDUCATION_TYPE
cross_table <- table(new_data$NAME_EDUCATION_TYPE, new_data$NAME_FAMILY_STATUS)
cross_table
# Perform the chi-square test
chisq_result <- chisq.test(cross_table)

# Print the chi-square test result
print(chisq_result)

# Calculate the critical value
critical_value <- qchisq(1 - alpha, df = chisq_result$parameter)

# Print the critical value
cat("Critical Value:", critical_value, "\n")

# Set up smaller plot size
par(cex = 0.8)

# Define the degrees of freedom
df <- 16

# Create density curve for chi-square distribution
curve(dchisq(x, df = df), from = 0, to = 60,
      main = 'Chi-Square Distribution (df = 16)',
      ylab = '',
      xlab = 'Chi-Square Value',
      lwd = 2)

# Calculate critical value based on alpha level (0.05)
alpha <- 0.05
critical_value <- qchisq(1 - alpha, df)

# Fill in portion of the density plot for the critical region
x_fill <- seq(critical_value, 100, length.out = 1000)
y_fill <- dchisq(x_fill, df = df)
polygon(c(critical_value, x_fill, 100), c(0, y_fill, 0), col = adjustcolor('red', alpha = 0.3), border = NA)

# Add red vertical line for critical value
abline(v = critical_value, col = "red", lwd = 2)

# Add x-axis
axis(side = 1, lwd = 1)

# Remove y-axis line
axis(side = 2, lwd = 0)

# Result:
# The results indicate a statistically significant association. 
# The p-value is very close to zero (p-value < 2.2e-16), suggesting that there is strong evidence to reject the null hypothesis of independence.

# ANOVA
# Example: ANOVA for AMT_INCOME_TOTAL by NAME_EDUCATION_TYPE
anova_model <- aov(AMT_INCOME_TOTAL ~ NAME_EDUCATION_TYPE, data = new_data)
summary(anova_model)

# Result: 
# The ANOVA results indicate that there is a statistically significant difference in the means of the variable AMT_INCOME_TOTAL across different levels of the categorical variable NAME_EDUCATION_TYPE. 
# The p-value (Pr(>F)) is very close to zero (p-value < 2e-16), suggesting that the differences are unlikely to be due to random chance.
# In other words, the education level appears to have a significant impact on the income total.


# Pearson Correlation Coefficients
# Load CSV file
application_data <- read.csv("/Users/theresalee/Desktop/UTM/SEM1 /Statistics/Assignment/application_record.csv")
credit_data <- read.csv("/Users/theresalee/Desktop/UTM/SEM1 /Statistics/Assignment/credit_record.csv")

# Merge two tables by 'ID'
merged_data <- merge(application_data, credit_data, by = "ID", all.x = TRUE)

# Let 'STATUS' 0 and 'C' are considered 'good', others are 'bad'
merged_data$STATUS <- ifelse(merged_data$STATUS %in% c(0, 'C'), 'Good', 'Bad')

# Convert categorical variables into numerical using one-hot encoding
merged_data_numerical <- model.matrix(~ . - 1, data = merged_data)

# Check for missing values in a dataframe
has_missing <- anyNA(merged_data)
has_missing # True means has missing values

# Remove missing values from a dataframe
merged_data <- na.omit(merged_data)

# Extract rows where STATUS column has value "Good"
STATUSGood <- merged_data$STATUS == "Good"

# Check the number of rows where STATUS is "Good"
sum(STATUSGood)

# Select only numeric variables and add STATUSGood as a column
numeric_data <- merged_data[, sapply(merged_data, is.numeric)]
numeric_data <- cbind(numeric_data, STATUSGood = STATUSGood)

# Calculate Pearson correlation coefficients
correlation_results <- cor(numeric_data, use="pairwise.complete.obs")

# In R, the correlation coefficient between a variable and itself is always 1. 
# However, when calculating the correlation matrix using cor(), the function automatically detects columns with zero variance (i.e., FLAG_MOBIL) and removes it from the output. 
# Since "FLAG_MOBIL" has only one unique value (which is 1, as it's a binary flag), it has zero variance.
# Therefore, R will omits it from the correlation matrix and it will shows as 'NA'.

library(ggplot2)

# Calculate correlation coefficient
correlation_coef <- cor(numeric_data$FLAG_WORK_PHONE, numeric_data$STATUSGood)

# Scatter plot with line of best fit
ggplot(data = numeric_data, aes(x = FLAG_WORK_PHONE, y = STATUSGood)) +
  geom_jitter(width = 0.2, height = 0.1) +
  geom_smooth(method = "lm", se = FALSE, color = "blue") +
  labs(x = "Work Phone", y = "Loan Status", title = "Scatter Plot: Work Phone vs. Loan Status") +
  geom_text(x = 0.5, y = 0.9, label = paste("Correlation:", round(correlation_coef, 2)), color = "blue")

# Scatter plot for DAYS_BIRTH and STATUSGood
ggplot(data = merged_data, aes(x = DAYS_BIRTH, y = STATUSGood)) +
  geom_jitter(width = 0.2, height = 0.1) +
  labs(x = "Days Birth", y = "Loan Status") +
  ggtitle("Scatter Plot: Days Birth vs. Loan Status")

# Scatter plot for CNT_CHILDREN and CNT_FAM_MEMBERS
plot(numeric_data$CNT_CHILDREN, numeric_data$CNT_FAM_MEMBERS,
     xlab = "Number of Children",
     ylab = "Number of Family Members",
     main = "Scatter plot: Number of Children vs Number of Family Members")

# Scatter plot for AMT_INCOME_TOTAL
ggplot(data = merged_data, aes(x = AMT_INCOME_TOTAL, y = STATUSGood)) +
  geom_point() +
  labs(x = "Income Total", y = "Loan Status") +
  ggtitle("Scatter Plot: Income Total vs. Loan Status")

#############################

# Logistic Regression to Identify the Binary Output
library(ggplot2)
library(rsample)
library(caret)
library(class)
library(gtools)
library(CMplot)
library(dplyr)

application_record <- read.csv("/Users/theresalee/Desktop/UTM/SEM1 /Statistics/Assignment/application_record.csv")
credit_record <- read.csv("/Users/theresalee/Desktop/UTM/SEM1 /Statistics/Assignment/credit_record.csv")

# Preview Credit Record
glimpse(credit_record)

# Preview Application Record
glimpse(application_record)

# Change the data type and adjust some character values to binary

application_record <- application_record %>% 
  mutate_if(is.character, as.factor) %>% 
  mutate_if(is.double, as.integer) %>% 
  mutate(CODE_GENDER = as.integer(ifelse(CODE_GENDER == "M", 1, 0)),
         FLAG_OWN_CAR = as.integer(ifelse(FLAG_OWN_CAR == "Y", 1, 0)),
         FLAG_OWN_REALTY = as.integer(ifelse(FLAG_OWN_REALTY == "Y", 1, 0)))

# Combine credit_record and application_record

credit_data <- merge(application_record, credit_record, by = "ID") %>% 
  select(-ID)

# Inspect NAME_INCOME_TYPE

credit_data %>% 
  select(NAME_INCOME_TYPE, STATUS) %>% 
  group_by(NAME_INCOME_TYPE, STATUS) %>% 
  summarise(Freq = n())

# Inspect NAME_EDUCATION_TYPE
credit_data %>% 
  select(NAME_EDUCATION_TYPE, STATUS) %>% 
  group_by(NAME_EDUCATION_TYPE, STATUS) %>% 
  summarise(Freq = n())

# Inspect NAME_FAMILY_STATUS
credit_data %>% 
  select(NAME_FAMILY_STATUS, STATUS) %>% 
  group_by(NAME_FAMILY_STATUS, STATUS) %>% 
  summarise(Freq = n())

# Inspect NAME_HOUSING_TYPE
credit_data %>% 
  select(NAME_HOUSING_TYPE, STATUS) %>% 
  group_by(NAME_HOUSING_TYPE, STATUS) %>% 
  summarise(Freq = n())

# Inspect OCCUPATION_TYPE
credit_data %>% 
  select(OCCUPATION_TYPE, STATUS) %>% 
  group_by(OCCUPATION_TYPE, STATUS) %>% 
  summarise(Freq = n())

# Inspect FLAG_MOBIL
unique(credit_data$FLAG_MOBIL)

# Remove problematic values and column
credit_data <- credit_data %>% 
  filter(NAME_INCOME_TYPE != "Student",
         NAME_EDUCATION_TYPE != "Academic degree",
         !OCCUPATION_TYPE %in% c("",
                                 "HR staff",
                                 "Private service staff",
                                 "Realty agents"))

# Modeling 

# Cross Validation

# Separate train and test data
set.seed(129)
index <- sample(nrow(credit_data), nrow(credit_data) * 0.75)
credit_train <- credit_data[index,]
credit_test <- credit_data[-index,]

# Separate train and test data only for numerical data
set.seed(129)

credit_data_num <- credit_data %>% 
  select(STATUS, where(is.numeric))

index <- sample(nrow(credit_data_num), nrow(credit_data_num) * 0.75)
credit_train_num <- credit_data_num[index,]

# Inspect the data balance of our target
table(credit_train$STATUS)
table(credit_train_num$STATUS)
prop.table(table(credit_train$STATUS))
prop.table(table(credit_train_num$STATUS))

# Balancing
# Convert STATUS to factor in both datasets
credit_train$STATUS <- factor(credit_train$STATUS)
credit_train_num$STATUS <- factor(credit_train_num$STATUS)

# Reduce half of the "Good Customer" data
ct_0 <- credit_train %>% 
  filter(STATUS == "Good Customer") %>% 
  slice(-c(1:9000))

ct_1 <- credit_train %>% 
  filter(STATUS == "Bad Customer")

credit_train <- rbind(ct_0, ct_1)

ctn_0 <- credit_train_num %>% 
  filter(STATUS == "Good Customer") %>% 
  slice(-c(1:9000))

ctn_1 <- credit_train_num %>% 
  filter(STATUS == "Bad Customer")

credit_train_num <- rbind(ctn_0, ctn_1)

# Convert STATUS to factor again after data reduction
credit_train$STATUS <- factor(credit_train$STATUS)
credit_train_num$STATUS <- factor(credit_train_num$STATUS)

# Now, let's retry the up-sampling
set.seed(129)
ups_train <- upSample(x = credit_train %>% select(-STATUS),
                      y = credit_train$STATUS,
                      yname = "STATUS")

ups_train_num <- upSample(x = credit_train_num %>% select(-STATUS),
                          y = credit_train_num$STATUS,
                          yname = "STATUS")

# Check the resulting balanced datasets
print("Balanced Dataset (ups_train):")
table(ups_train$STATUS)

print("Balanced Dataset (ups_train_num):")
table(ups_train_num$STATUS)


# Now, let's retry the up-sampling
set.seed(129)
ups_train <- upSample(x = credit_train %>% select(-STATUS),
                      y = credit_train$STATUS,
                      yname = "STATUS")

ups_train_num <- upSample(x = credit_train_num %>% select(-STATUS),
                          y = credit_train_num$STATUS,
                          yname = "STATUS")

# Check the resulting balanced datasets
table(ups_train$STATUS)
table(ups_train_num$STATUS)

# Logistic modeling

# Modeling using all predictors
model_all <- glm(STATUS ~ ., ups_train, family = "binomial")
model_all_num <- glm(STATUS ~ ., ups_train_num, family = "binomial")


# Modeling using stepwise method
model_step <- step(glm(STATUS ~ ., ups_train, family = "binomial"), direction = "backward")
model_step_num <- step(glm(STATUS ~ ., ups_train_num, family = "binomial"), direction = "backward")

# Model summary
summary(model_all)
summary(model_all_num)
summary(model_step)
summary(model_step_num)

# Odds and Probability
exp(-3.3429657987)
inv.logit(-3.3429657987)

# The NAME_INCOME_TYPEPensioner predictor has dervied to obtain the odds and the probability value.
# People who are pensioner have 0.035 tines more likely become a bad customer.
# There has an increase of 3.4% of probability that pensioner become a bad customers.

# Prediction of the models
pred_all <- predict(model_all, credit_test, type = "response")
pred_all_num <- predict(model_all_num, credit_test, type = "response")
pred_step <- predict(model_step, credit_test, type = "response")
pred_step_num <- predict(model_step_num, credit_test, type = "response")

# Convert the prediction value to real result
test_all <- credit_test
test_all_num <- credit_test
test_step <- credit_test
test_step_num <- credit_test

test_all$pred <- factor(ifelse(pred_all > 0.5, "Bad Customer", "Good Customer"))
test_all_num$pred <- factor(ifelse(pred_all_num > 0.5, "Bad Customer", "Good Customer"))
test_step$pred <- factor(ifelse(pred_step > 0.5, "Bad Customer", "Good Customer"))
test_step_num$pred <- factor(ifelse(pred_step_num > 0.5, "Bad Customer", "Good Customer"))

# Preview the performance of each model
confusionMatrix(test_all$pred, test_all$STATUS, positive = "Good Customer")
confusionMatrix(test_all_num$pred, test_all_num$STATUS, positive = "Good Customer")
confusionMatrix(test_step$pred, test_step$STATUS, positive = "Good Customer")
confusionMatrix(test_step_num$pred, test_step_num$STATUS, positive = "Good Customer")

# Model tuning

# Load caret package
library(caret)

# Create confusion matrix
conf_matrix <- confusionMatrix(test_step$pred, test_step$STATUS)

# Plot confusion matrix
plot(conf_matrix$table, col = conf_matrix$byClass, 
main = "Confusion Matrix", 
xlab = "Predicted", 
ylab = "Actual")
print(conf_matrix)

# Reinstall and load CMplot package
if (!requireNamespace("CMplot", quietly = TRUE)) {
  install.packages("CMplot")
}
library(CMplot)

# Tuning
# Before tuning
test_step$pred <- factor(ifelse(pred_step > 0.9, "Bad Customer", "Good Customer"))
confusionMatrix(test_step$pred, test_step$STATUS, positive = "Good Customer")

# After tuning
test_step$pred <- factor(ifelse(pred_step > 0.6, "Bad Customer", "Good Customer"))
confusionMatrix(test_step$pred, test_step$STATUS, positive = "Good Customer")

# Line Chart for Logistic Regression Performance

# Load required libraries
install.packages("plotly")

# Load required libraries
library(plotly)
library(caret)
library(pROC)

cutoff <- seq(0.1, 0.9, by = 0.1)  # Assuming cutoff values range from 0.1 to 0.9

# Initialize empty vectors to store metrics
sensitivity <- numeric(length(cutoff))
specificity <- numeric(length(cutoff))
accuracy <- numeric(length(cutoff))
precision <- numeric(length(cutoff))
recall <- numeric(length(cutoff))
auc <- numeric(length(cutoff))

# Iterate through cutoff values
for (i in seq_along(cutoff)) {
  
  # Update predictions based on the current cutoff
  test_step$pred <- factor(ifelse(pred_step > cutoff[i], "Bad Customer", "Good Customer"))
  
  # Generate confusion matrix
  conf_matrix <- confusionMatrix(test_step$pred, test_step$STATUS, positive = "Good Customer")
  
  # Calculate and store sensitivity, specificity, accuracy, precision, and recall
  sensitivity[i] <- conf_matrix$byClass["Sensitivity"]
  specificity[i] <- conf_matrix$byClass["Specificity"]
  accuracy[i] <- conf_matrix$overall["Accuracy"]
  precision[i] <- conf_matrix$byClass["Pos Pred Value"]
  recall[i] <- sensitivity[i]  # Recall is the same as sensitivity
  
  # Calculate AUC
  roc_data <- roc(as.numeric(test_step$STATUS == "Good Customer"), as.numeric(pred_step))
  auc[i] <- auc(roc_data)
}

# Print the values
print(sensitivity)
print(specificity)
print(accuracy)
print(precision)
print(recall)
print(auc)

# Create a dataframe
df <- data.frame(cutoff, sensitivity, specificity, accuracy, precision, recall)

# Plot the line chart
plot <- plot_ly(data = df, x = ~cutoff) %>%
  add_lines(y = ~sensitivity, name = 'Sensitivity', text = ~paste("Cutoff:", cutoff, "<br>Sensitivity:", sensitivity),
            hoverinfo = "text") %>%
  add_lines(y = ~specificity, name = 'Specificity', text = ~paste("Cutoff:", cutoff, "<br>Specificity:", specificity),
            hoverinfo = "text") %>%
  add_lines(y = ~accuracy, name = 'Accuracy', text = ~paste("Cutoff:", cutoff, "<br>Accuracy:", accuracy),
            hoverinfo = "text") %>%
  add_lines(y = ~precision, name = 'Precision', text = ~paste("Cutoff:", cutoff, "<br>Precision:", precision),
            hoverinfo = "text") %>%
  add_lines(y = ~recall, name = 'Recall', text = ~paste("Cutoff:", cutoff, "<br>Recall:", recall),
            hoverinfo = "text") %>%
  layout(title = 'Performance Metrics vs. Cutoff',
         xaxis = list(title = 'Cutoff'),
         yaxis = list(title = 'Performance Value'),
         hovermode = 'closest')

# Display the plot
plot

# Scatter Plot for Cutoff Comparison 

# Plot sensitivity vs. cutoff with color 'blue'
plot_sensitivity <- plot_ly(data = df, x = ~cutoff, y = ~sensitivity, type = 'scatter', mode = 'markers',
                            marker = list(size = 10, color = ("blue")),
                            text = ~paste("Cutoff:", cutoff, "<br>Sensitivity:", sensitivity),
                            hoverinfo = "text", name = "Sensitivity") %>%
  layout(title = 'Sensitivity vs. Cutoff',
         xaxis = list(title = 'Cutoff'),
         yaxis = list(title = 'Sensitivity'))
print(plot_sensitivity)

# Plot specificity vs. cutoff with color 'red'
plot_specificity <- plot_ly(data = df, x = ~cutoff, y = ~specificity, type = 'scatter', mode = 'markers',
                            marker = list(size = 10, color = ("red")),
                            text = ~paste("Cutoff:", cutoff, "<br>Specificity:", specificity),
                            hoverinfo = "text", name = "Specificity") %>%
  layout(title = 'Specificity vs. Cutoff',
         xaxis = list(title = 'Cutoff'),
         yaxis = list(title = 'Specificity'))
print(plot_specificity)

# Plot accuracy vs. cutoff with color 'green'
plot_accuracy <- plot_ly(data = df, x = ~cutoff, y = ~accuracy, type = 'scatter', mode = 'markers',
                         marker = list(size = 10, color = ("green")),
                         text = ~paste("Cutoff:", cutoff, "<br>Accuracy:", accuracy),
                         hoverinfo = "text", name = "Accuracy") %>%
  layout(title = 'Accuracy vs. Cutoff',
         xaxis = list(title = 'Cutoff'),
         yaxis = list(title = 'Accuracy'))
print(plot_accuracy)

# Plot precision vs. cutoff with color 'orange'
plot_precision <- plot_ly(data = df, x = ~cutoff, y = ~precision, type = 'scatter', mode = 'markers',
                          marker = list(size = 10, color = ("orange")),
                          text = ~paste("Cutoff:", cutoff, "<br>Precision:", precision),
                          hoverinfo = "text", name = "Precision") %>%
  layout(title = 'Precision vs. Cutoff',
         xaxis = list(title = 'Cutoff'),
         yaxis = list(title = 'Precision'))
print(plot_precision)

# Plot recall vs. cutoff with color 'purple'
plot_recall <- plot_ly(data = df, x = ~cutoff, y = ~recall, type = 'scatter', mode = 'markers',
                       marker = list(size = 10, color = ("purple")),
                       text = ~paste("Cutoff:", cutoff, "<br>Recall:", recall),
                       hoverinfo = "text", name = "Recall") %>%
  layout(title = 'Recall vs. Cutoff',
         xaxis = list(title = 'Cutoff'),
         yaxis = list(title = 'Recall'))
print(plot_recall)

# Plot AUC vs. cutoff with color 'brown'
plot_auc <- plot_ly(data = df, x = ~cutoff, y = ~auc, type = 'scatter', mode = 'markers',
                    marker = list(size = 10, color = ("brown")),
                    text = ~paste("Cutoff:", cutoff, "<br>AUC:", auc),
                    hoverinfo = "text", name = "AUC") %>%
  layout(title = 'AUC vs. Cutoff',
         xaxis = list(title = 'Cutoff'),
         yaxis = list(title = 'AUC'))
print(plot_auc)

# Display the scatter plots with custom legend names and colors
subplot(plot_sensitivity, plot_specificity, plot_accuracy, plot_precision, plot_recall, plot_auc, nrows = 3) %>%
  layout(legend = list(
    orientation = "h",  # Horizontal legend
    x = 0.5,             # Adjust the x position
    y = -0.15,           # Adjust the y position
    traceorder = "normal",
    font = list(
      family = "sans-serif",
      size = 12,
      color = "black"
    ),
    bgcolor = "#f8f9fa",  # Background color
    bordercolor = "black",# Border color
    borderwidth = 1       # Border width
  ))

# Create tables for each metric
table_sensitivity <- df %>%
  select(cutoff, sensitivity) %>%
  rename(Value = sensitivity) %>%
  mutate(Metric = "Sensitivity")

table_specificity <- df %>%
  select(cutoff, specificity) %>%
  rename(Value = specificity) %>%
  mutate(Metric = "Specificity")

table_accuracy <- df %>%
  select(cutoff, accuracy) %>%
  rename(Value = accuracy) %>%
  mutate(Metric = "Accuracy")

table_precision <- df %>%
  select(cutoff, precision) %>%
  rename(Value = precision) %>%
  mutate(Metric = "Precision")

table_recall <- df %>%
  select(cutoff, recall) %>%
  rename(Value = recall) %>%
  mutate(Metric = "Recall")

table_auc <- df %>%
  select(cutoff, Value = sensitivity) %>%
  mutate(Metric = "AUC")

# Combine tables
combined_table <- bind_rows(table_sensitivity, table_specificity, table_accuracy, 
                            table_precision, table_recall, table_auc)

# Display the combined table
combined_table


###############################

# Random Forest Classification Model for Highest Accuracy

# Load CSV file
application_data <- read.csv("/Users/theresalee/Desktop/UTM/SEM1 /Statistics/Assignment/application_record.csv")
credit_data <- read.csv("/Users/theresalee/Desktop/UTM/SEM1 /Statistics/Assignment/credit_record.csv")

# Merge two tables by 'ID'
merged_data <- merge(application_data, credit_data, by = "ID", all.x = TRUE)

# Let 'STATUS' 0 and 'C' are considered 'good', others are 'bad'
merged_data$STATUS <- ifelse(merged_data$STATUS %in% c(0, 'C'), 'Good', 'Bad')

# Handle unbalanced data using oversampling
oversampled_data <- ROSE::ovun.sample(STATUS ~ ., data = merged_data, method = "over", N = nrow(merged_data) * 0.8, seed = 123)$data

# Get the count of the minority class
minority_count <- sum(merged_data$STATUS == "Bad")

# Set the sampling size as a fraction of the minority class size
undersampling_rate <- 0.8  # You can adjust this rate as needed
sampling_size <- round(minority_count * undersampling_rate)

# Handle unbalanced data using undersampling
undersampled_data <- ROSE::ovun.sample(STATUS ~ ., data = merged_data, method = "under", N = sampling_size, seed = 123)$data

# Ensure 'STATUS' is a factor
undersampled_data$STATUS <- as.factor(undersampled_data$STATUS)

# Create a data partition
trainIndex <- createDataPartition(undersampled_data$STATUS, p = 0.8, list = FALSE)
train_data <- undersampled_data[trainIndex, ]
test_data <- undersampled_data[-trainIndex, ]

# Set seed and create a smaller subset for training
set.seed(123)

# Check if the sample size is larger than the population size
if (nrow(train_data) <= 1000) {
  # If the population size is smaller or equal to the desired sample size, use the entire dataset
  small_train_data <- train_data
} else {
  # If the population size is larger than the desired sample size, take a random sample for reduce time consuming
  small_train_data <- train_data[sample(nrow(train_data), size = 1000, replace = FALSE), ]
}

# Create a cluster for parallel processing
cl <- makeCluster(detectCores())
registerDoParallel(cl)

# Build random forest models in parallel
models <- foreach(ntree = c(50, 100), .combine = combine, .packages = "randomForest") %dopar% {
  randomForest(STATUS ~ ., data = small_train_data, type = "classification", ntree = ntree, maxdepth = 5)
}

# Stop the parallel cluster
stopCluster(cl)

# Combine the models 
model <- combine(models)

# Make predictions on the test set
predictions <- predict(model, test_data)

# Evaluate the model (add appropriate metrics)
conf_matrix <- confusionMatrix(predictions, test_data$STATUS)
print(conf_matrix)

## Visualize the Random Forest Model predictive result
# Install and load required packages 
if (!requireNamespace("caret", quietly = TRUE)) {
  install.packages("caret")
}

if (!requireNamespace("pROC", quietly = TRUE)) {
  install.packages("pROC")
}

# Let 'Bad' be the positive class
# Create a confusion matrix
conf_matrix <- confusionMatrix(predictions, test_data$STATUS)

# Extract the confusion matrix table
conf_table <- conf_matrix$table

# Plot the mosaic plot
mosaicplot(conf_table, main = "Confusion Matrix", col = c("lightgreen", "lightcoral"), border = "black")

# Add accuracy, sensitivity, and specificity to the plot
text(3, 1, paste("Accuracy =", paste0(round(as.numeric(conf_matrix$overall["Accuracy"]) * 100, 2), "%")), col = "black")
text(3, 2, paste("Sensitivity =", paste0(round(as.numeric(conf_matrix$byClass["Sensitivity"]) * 100, 2), "%")), col = "black")
text(3, 3, paste("Specificity =", paste0(round(as.numeric(conf_matrix$byClass["Specificity"]) * 100, 2), "%")), col = "black")

# Add values to the confusion matrix plot
text(1, 2, paste("True Positives =", as.character(conf_matrix$table[2, 2])), col = "black")
text(1, 3, paste("False Negatives =", as.character(conf_matrix$table[2, 1])), col = "black")
text(2, 2, paste("False Positives =", as.character(conf_matrix$table[1, 2])), col = "black")
text(2, 3, paste("True Negatives =", as.character(conf_matrix$table[1, 1])), col = "black")

# Plot ROC curve
auc_value <- auc(roc_curve)
text(0.8, 0.2, paste("AUC =", round(auc_value, 2)), col = "blue")

# Plot ROC curve
plot(roc_curve, main = "ROC Curve", col = "blue", lwd = 2)

# Add a legend
legend("bottomright", legend = paste("AUC =", round(auc_value, 2)), col = "blue", lty = 1)
